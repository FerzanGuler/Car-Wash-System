package sen2212;


public class NodeBT {
	int key;
	String name;
	
	NodeBT leftChild;
	NodeBT rightChild;
	
	
	NodeBT(int key, String name){
		this.key = key;
		
		this.name = name;
		
	}
	public String toString() {
		return name + " " + key;
	}

}
