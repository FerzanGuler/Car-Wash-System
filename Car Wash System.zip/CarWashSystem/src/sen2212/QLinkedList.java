package sen2212;

public class QLinkedList {

	private Node front;
	private Node rear;
	private int size;
	
	
	public QLinkedList(Node front, Node rear, int size) {
		super();
		this.front = front;
		this.rear = rear;
		this.size = size;
	}
	
	public boolean isEmpty() {
		if(front == rear)
			return false;
		else 
			return true;
	}
	public void enqueue(Car data) {
		
		Node oldRear = rear;
		rear = new Node();
		rear.setData(data);
		rear.setNext(null);
		if (isEmpty())
			front = rear;
		else
			oldRear.setNext(rear);
		size++;
		System.out.println(data + " added to the queue");
	}

	
	public Car dequeue() {
		Car data = front.getData();
		front = front.getNext();
		if (isEmpty())
			rear = null;
		size--;
		System.out.println(data + " removed from the queue");

		return data;
	}
	
	public Node getFront() {
		return front;
	}

	public void setFront(Node front) {
		this.front = front;
	}

	@Override
	public String toString() {
		return  " " +front + rear + size + "]";
	}
	
	 
}
