package sen2212;

public class Node {
	private Car data;
	private Node next;
	
	public Node() {
		
	}

	public Car getData() {
		return data;
	}

	public void setData(Car data) {
		this.data = data;
	}

	public Node getNext() {
		return next;
	}

	public void setNext(Node next) {
		this.next = next;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return data.toString();
	}

}
