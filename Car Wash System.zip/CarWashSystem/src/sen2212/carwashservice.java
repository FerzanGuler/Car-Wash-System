package sen2212;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLayeredPane;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;

import com.sun.webkit.ContextMenu.ShowContext;
import com.sun.xml.internal.ws.api.ha.StickyFeature;

import java.awt.CardLayout;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;

public class carwashservice implements ActionListener, MouseListener{

	JLabel lblClock = new JLabel("New label");
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	JButton add = new JButton("ADD");
	JButton quit = new JButton("Get Out of Line");
	DefaultListModel<QLinkedList> allCar = new DefaultListModel<QLinkedList>();
	JList list = new JList(allCar);
	JScrollPane sp = new JScrollPane(list);
	DefaultListModel<BinaryTree> allCar2 = new DefaultListModel<BinaryTree>();
	JList list2 = new JList(allCar2);
	JScrollPane sp2 = new JScrollPane(list2);
	JRadioButton rdbtnNewRadioButton = new JRadioButton("Basic 10 $");
	JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Standart 15 $");
	JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Deluxe 20 $");


	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					carwashservice window = new carwashservice();
					window.frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void clock() {
		
		Thread clock=new Thread() {
			public void run() 
			{
				try {
					for(;;) {
					Calendar cal = new GregorianCalendar();
					int day=cal.get(Calendar.DAY_OF_MONTH);
					int month=cal.get(Calendar.MONTH);
					int year=cal.get(Calendar.YEAR);
					
					int second=cal.get(Calendar.SECOND);
					int minute=cal.get(Calendar.MINUTE);
					int hour=cal.get(Calendar.HOUR);

					lblClock.setText("Time  "+hour+":"+minute+":"+second+"	Date "+year+"/"+month+"/"+day);
					sleep(1000);
					}
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}
			
		};
		clock.start(); 
	   
		
	}
	/**
	 * Create the application.
	 */
	public carwashservice() {
		clock();
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.LIGHT_GRAY);
		frame.getContentPane().setLayout(null);
		
		JLayeredPane layeredPane = new JLayeredPane();
		layeredPane.setBounds(182, 90, 525, 373);
		layeredPane.setBackground(Color.WHITE);
		frame.getContentPane().add(layeredPane);
		layeredPane.setLayout(new CardLayout(0, 0));
		
		final JPanel panel = new JPanel();
		layeredPane.add(panel, "name_236358249191983");
		panel.setLayout(null);
		
		final JPanel panel_1 = new JPanel();
		layeredPane.add(panel_1, "name_236358255602244");
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Name : ");
		lblNewLabel_1.setBounds(30, 33, 61, 16);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("SERA  ");
		lblNewLabel_2.setBounds(30, 74, 61, 16);
		panel_1.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(105, 28, 130, 26);
		panel_1.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(103, 69, 130, 26);
		panel_1.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setBounds(30, 115, 61, 16);
		panel_1.add(lblNewLabel_3);
		
		rdbtnNewRadioButton.addMouseListener(this);
		rdbtnNewRadioButton_1.addMouseListener(this);
		rdbtnNewRadioButton_2.addMouseListener(this);
		
		rdbtnNewRadioButton.setBounds(30, 156, 141, 23);
		panel_1.add(rdbtnNewRadioButton);
		
		
		rdbtnNewRadioButton_1.setBounds(30, 185, 141, 23);
		panel_1.add(rdbtnNewRadioButton_1);
		

		rdbtnNewRadioButton_2.setBounds(30, 213, 141, 23);
		panel_1.add(rdbtnNewRadioButton_2);
		
		
		add.setBounds(30, 321, 117, 29);
		panel_1.add(add);
		add.addActionListener(this);
		quit.addActionListener(this);
		
		lblClock.setBounds(277, 12, 323, 58);
		panel_1.add(lblClock);
		
		
		list.setBounds(277, 74, 214, 228);
		panel_1.add(list);
		
		
		quit.setBounds(152, 321, 117, 29);
		panel_1.add(quit);
		
		final JPanel panel_2 = new JPanel();
		layeredPane.add(panel_2, "name_236358261098553");
		panel_2.setLayout(null);
		
		
		list2.setBounds(68, 67, 411, 260);
		panel_2.add(list2);
		
		JLabel lblNewLabel_4 = new JLabel("New label");
        lblNewLabel_4.setIcon(new ImageIcon(carwashservice.class.getResource("/images/Ekran_Resmi_2021-05-21_23.32.53.png")));
        lblNewLabel_4.setBounds(27, 6, 468, 361);
        panel.add(lblNewLabel_4);
		
		final JButton btnNewButton = new JButton("Home");
		btnNewButton.setBounds(29, 193, 117, 29);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()== btnNewButton) {
					panel.setVisible(true);
					panel_1.setVisible(false);
					panel_2.setVisible(false);
					
				}
			}
		});
		frame.getContentPane().add(btnNewButton);
		
		final JButton btnNewButton_1 = new JButton("Add Car");
		btnNewButton_1.setBounds(29, 250, 117, 29);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()== btnNewButton_1) {
					
					panel_1.setVisible(true);
					panel.setVisible(false);
					panel_2.setVisible(false);
				}
			}
		});
		frame.getContentPane().add(btnNewButton_1);
		
		final JButton btnNewButton_2 = new JButton("List of Cars");
		btnNewButton_2.setBounds(29, 308, 117, 29);
		btnNewButton_2.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
		
				if(e.getSource()== btnNewButton_2) {
				
					panel_2.setVisible(true);
					panel.setVisible(false);
					panel_1.setVisible(false);
				}
			
			}
			
		});
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(0, 6, 214, 171);
		lblNewLabel.setIcon(new ImageIcon(carwashservice.class.getResource("/images/output-onlinegiftools.gif")));
		frame.getContentPane().add(lblNewLabel);
		frame.setBounds(100, 100, 733, 528);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	int z = 1;
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == add) {
			if(rdbtnNewRadioButton.isSelected()) {
			Car a = new Car(textField.getText(), textField_1.getText(), " 10 $");
			QLinkedList araba = new QLinkedList(null, null, z);
			araba.enqueue(a);
			allCar.addElement(araba);
			BinaryTree tumArabalar = new BinaryTree();
			tumArabalar.addNode(z,textField.getText() + " " + textField_1.getText() + " " + lblClock.getText().toString());
			z++;
			allCar2.addElement(tumArabalar);
			Clear();
		
			
		}else if(rdbtnNewRadioButton_1.isSelected()) {
			
			Car a = new Car(textField.getText(), textField_1.getText(), " 15 $");
			QLinkedList araba = new QLinkedList(null, null, z);
			araba.enqueue(a);
			allCar.addElement(araba);
			BinaryTree tumArabalar = new BinaryTree();
			tumArabalar.addNode(z,textField.getText() + " " + textField_1.getText() + " " + lblClock.getText().toString() );
			z++;
			allCar2.addElement(tumArabalar);
			Clear();
		
		}else if(rdbtnNewRadioButton_2.isSelected()) {
			Car a = new Car(textField.getText(), textField_1.getText(), " 20 $");
			QLinkedList araba = new QLinkedList(null, null, z);
			araba.enqueue(a);
			allCar.addElement(araba);
			BinaryTree tumArabalar = new BinaryTree();
			tumArabalar.addNode(z,textField.getText() + " " + textField_1.getText() + " " + lblClock.getText().toString() );
			z++;
			allCar2.addElement(tumArabalar);
			Clear();
		}else {
			JOptionPane.showMessageDialog(null, "Please fill the empty area");
			
		}
		
			NodeBT root = null;
			 if(z == 0) {
			 
				 root = new NodeBT(z, textField.getText());
			 }
			
			 
		}if(e.getSource() == quit) {
			if(allCar.isEmpty()) {		
				JOptionPane.showMessageDialog(null, "There is no car in list");
				
			}else {
				QLinkedList B = allCar.get(list.getSelectedIndex());
				
				
				allCar.removeElement(B);
				B.dequeue();
			}
		}
		
		
	}
		public void Clear() {
		textField.setText("");
		textField_1.setText("");
		rdbtnNewRadioButton.setSelected(false);
		rdbtnNewRadioButton_1.setSelected(false);
		rdbtnNewRadioButton_2.setSelected(false);
	}

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource() == rdbtnNewRadioButton) {
				rdbtnNewRadioButton_1.setSelected(false);
				rdbtnNewRadioButton_2.setSelected(false);
			}else if (e.getSource() == rdbtnNewRadioButton_1) {
				rdbtnNewRadioButton.setSelected(false);
				rdbtnNewRadioButton_2.setSelected(false);
			}else if (e.getSource() == rdbtnNewRadioButton_2){
				rdbtnNewRadioButton.setSelected(false);
				rdbtnNewRadioButton_1.setSelected(false);
			}
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
}
