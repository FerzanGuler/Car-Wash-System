package sen2212;

public class Car {
	
	public String name;
	public String plate;
	public String mod;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPlate() {
		return plate;
	}
	public void setPlate(String plate) {
		this.plate = plate;
	}
	public String getMod() {
		return mod;
	}
	public void setMod(String mod) {
		this.mod = mod;
	}
	public Car(String name, String plate, String mod) {
		super();
		this.name = name;
		this.plate = plate;
		this.mod = mod;
	}
	@Override
	public String toString() {
		return "Car [name=" + name + ", plate=" + plate + ", mod=" + mod + "]";
	}
	
	
	
	

}
