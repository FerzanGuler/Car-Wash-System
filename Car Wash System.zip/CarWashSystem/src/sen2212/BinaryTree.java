package sen2212;

public class BinaryTree {
	NodeBT root;
	
	public void addNode(int key , String name) {
		NodeBT newNode = new NodeBT(key, name);
		 if(root == null) {
			 root = newNode;
		 }else {
			 NodeBT focusNode = root;
			 
			 NodeBT parent;
			 
			 while(true) {
				 parent = focusNode;
				 
				 if(key < focusNode.key) {
					 focusNode = focusNode.leftChild;
					 if(focusNode == null) {
						 parent.leftChild = newNode;
						 return;
					 }
						 
				 }else {
					 focusNode = focusNode.rightChild;
					 if(focusNode == null) {
						 parent.rightChild = newNode;
						 return;
					 }
				 }
			 }
		 }
	}
	
	
	public NodeBT getRoot() {
		return root;
	}


	public void setRoot(NodeBT root) {
		this.root = root;
	}


	public void inOrderTraverselTree(NodeBT root) {
		if(root != null) {
			inOrderTraverselTree(root.leftChild);
			System.out.println(root.name);
			inOrderTraverselTree(root.rightChild);
		}
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return root.name.toString();
	}




}
